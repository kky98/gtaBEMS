import joblib
from flask import Flask, jsonify
from flask_cors import CORS
from ac_predict_model import ac_predict_with_model
from total_predict_model import to_predict_with_model
from plug_predict_model import pl_predict_with_model
from light_predict_model import li_predict_with_model
from datetime import datetime

app = Flask(__name__)
CORS(app)

# 각 모델을 전역으로 로드
ac_loaded_model = joblib.load('ac_model.h5')
total_loaded_model = joblib.load('total_model.h5')
plug_loaded_model = joblib.load('plug_model.h5')
light_loaded_model = joblib.load('light_model.h5')


def predict_with_model(model, predict_function):
    start_time = datetime.now()
    prediction = predict_function(model)
    end_time = datetime.now()
    log_path = "C:/Users/rlarb/PycharmProjects/pythonProject/GTA/log/server_log.txt"
    # 함수 실행 시간을 로그 파일에 저장
    log_message = f"{predict_function.__name__} - Elapsed time: {end_time - start_time}\n"
    with open(log_path, 'a') as log_file:
        log_file.write(log_message)

    print(prediction)
    return jsonify(prediction=prediction)


@app.route('/ac', methods=['POST'])
def get_ac_prediction():
    return predict_with_model(ac_loaded_model, ac_predict_with_model)


@app.route('/total', methods=['POST'])
def get_total_prediction():
    return predict_with_model(total_loaded_model, to_predict_with_model)


@app.route('/plug', methods=['POST'])
def get_plug_prediction():
    return predict_with_model(plug_loaded_model, pl_predict_with_model)


@app.route('/light', methods=['POST'])
def get_light_prediction():
    return predict_with_model(light_loaded_model, li_predict_with_model)


if __name__ == '__main__':
    # 서버가 실행될 때 각 함수를 미리 호출
    get_ac_prediction()
    get_total_prediction()
    get_plug_prediction()
    get_light_prediction()

    app.run(debug=True)
