from apscheduler.schedulers.blocking import BlockingScheduler
import datetime
from mylogger import *
from train import *
import time
log = make_logger("sch.log","sch")
def test_cron():
    log.info("cron")
    print("hi")
    # 학습
    run(log)
def inter_val():
    print("hi2")
    log.info("interval")
    # 학습
    run(log)

sched = BlockingScheduler()
# 잡 등록  (10초에 한번씩 함수 호출)
sched.add_job(test_cron, 'interval', seconds=10)
# 월 오전 9시
sched.add_job(test_cron, 'cron', day_of_week='mon', hour='9')
sched.start()
