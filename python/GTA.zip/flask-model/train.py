from keras.models import load_model
from keras.models import Sequential
from keras.layers import Dense
from keras.datasets import mnist
import os
# 데이터셋 로드 (예: MNIST)
(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train, x_test = x_train / 255.0, x_test / 255.0
filename = 'D:/dev/pythonProject/ex-flask/flask-model/model.h5'
def model_load():
    if not os.path.exists(filename):
        # 모델 구성
        model = Sequential([
            Dense(128, activation='relu', input_shape=(784,)),
            Dense(10, activation='softmax')
        ])
        # 모델 컴파일
        model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    else:
        # 모델 로드
        model = load_model(filename)
    return model
def run(log):
    train_model = model_load()
    log.info("model load")
    # 새 데이터로 모델 학습 (여기서는 동일한 데이터셋 사용)
    # 실제로는 새로운 데이터를 로드하여 학습시킬 것입니다.
    train_model.fit(x_train.reshape(-1, 784), y_train, epochs=5)
    # 새 모델 평가
    new_accuracy = train_model.evaluate(x_test.reshape(-1, 784), y_test, verbose=0)[1]
    # 이전 모델과 비교
    try:
        old_model = load_model(filename)
        old_accuracy = old_model.evaluate(x_test.reshape(-1, 784), y_test, verbose=0)[1]
    except:
        old_accuracy = 0
    # 성능 비교 후 결정
    log.info("old acc:" + str(old_accuracy) + " new acc: " + str(new_accuracy) )
    if new_accuracy > old_accuracy:
        train_model.save(filename)  # 새 모델 저장
        print("New model saved.")
        log.info("New model saved.")
    else:
        print("Old model is better. No update.")
        log.info("Old model is better. No update.")