# pip install apscheduler
# pip install --upgrade apscheduler
import numpy as np
from flask import Flask, request, jsonify
import tensorflow as tf
from PIL import Image

import os
# 사용자 모듈

from mylogger import *
log = make_logger("flask.log","app")


app = Flask(__name__)
path ='D:/dev/pythonProject/ex-flask/flask-model/'
# 모델 불러오기
model = tf.keras.models.load_model(os.path.join(path , 'model.h5'))
@app.route('/predict', methods=['GET'])
def main():
    log.info("main call")
    # 테스트
    f = os.path.join(path, '1.JPG')
    image = Image.open(f)
    image = image.resize((28, 28)).convert('L')  # 흑백 28 X 28 변환
    image_arr = np.array(image)
    image_arr = image_arr.reshape(1, 784).astype('float32') / 255.0
    pred = model.predict(image_arr)
    pred_class = np.argmax(pred, axis=-1)[0]
    # 테스트
    return jsonify({'prediction': int(pred_class)})


if __name__ == '__main__':
    # ip port 변경
    log.info("app start")
    app.run(debug=True, port=5000)

