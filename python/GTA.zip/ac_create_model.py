import os
import pandas as pd
from prophet import Prophet
import joblib
import cx_Oracle
from datetime import datetime
from prophet.diagnostics import performance_metrics

# TNS_ADMIN 환경 변수 설정
os.environ["TNS_ADMIN"] = "C:/Users/rlarb/Downloads/WINDOWS.X64_193000_db_home/network/admin"

# Oracle DB 연결 설정
oracle_connection = cx_Oracle.connect('gta', 'gta', '192.168.0.42:1521/xe')

# SQL 쿼리 작성
sql_query = "SELECT * FROM be_device where b_id='gta'"

# Oracle DB에서 데이터 가져오기
df = pd.read_sql(sql_query, con=oracle_connection)
df.columns = df.columns.str.lower()

# 오늘 날짜 설정
today = datetime.now()

# 'be_date'를 기준으로 에너지 관련 열을 가져와 'ds', 'y'로 이름 변경
df = df[['be_date', 'be_ac_energy']].rename(columns={'be_date': 'ds', 'be_ac_energy': 'y'})

# 데이터 전처리: 'ds' 열을 datetime 형식으로 변환
df['ds'] = pd.to_datetime(df['ds'])

# 데이터 집계
df = df.groupby(pd.Grouper(key='ds', freq='1T')).agg({
    'y': 'sum'
}).reset_index()

# 4개월 데이터만 선택하여 모델 학습
train_df = df[(df['ds'] >= today - pd.DateOffset(months=4)) & (df['ds'] < today)]

# 'is_weekend' 열 추가
train_df = train_df.copy()  # train_df를 복사
train_df['is_weekend'] = (train_df['ds'].dt.dayofweek >= 5).astype(int)

# Prophet 모델 초기화 및 파라미터 튜닝
model = Prophet(
    yearly_seasonality=False,
    daily_seasonality=True,
    changepoint_prior_scale=0.01,  # 변화점의 유연성을 높임
    holidays_prior_scale=10.0,     # 휴일 효과의 유연성을 높임
    seasonality_prior_scale=10.0  # seasonality_prior_scale 값을 높게 조정
)
# 주말에 대한 주간 트렌드 추가
model.add_seasonality(name='weekend', period=7, fourier_order=40, condition_name='is_weekend')

# 모델 훈련
model.fit(train_df)

# 과거 모델 로드
old_model_filename = 'ac_model.h5'
try:
    old_model = joblib.load(old_model_filename)
except:
    old_model = None

# 예측 생성
future = model.make_future_dataframe(periods=365)  # 새 모델은 미래 365일에 대한 예측 생성
forecast = model.predict(future)

# 과거 모델의 예측 생성
if old_model:
    old_forecast = old_model.predict(future)
else:
    old_forecast = None

# 예측값과 실제값 간의 차이 계산
if old_forecast:
    performance_metrics_old = performance_metrics(old_forecast)
    print("Old Model Performance Metrics:")
    print(performance_metrics_old)

performance_metrics_new = performance_metrics(forecast)
print("\nNew Model Performance Metrics:")
print(performance_metrics_new)

# 성능 비교 후 결정
if old_forecast:
    if performance_metrics_new['rmse'].values[0] < performance_metrics_old['rmse'].values[0]:
        # 새 모델이 더 좋은 경우 새 모델 저장
        joblib.dump(model, old_model_filename)
        print("\nNew model is better. It has been saved.")
    else:
        print("\nOld model is better. No update.")
else:
    # 과거 모델이 없는 경우 새 모델 저장
    joblib.dump(model, old_model_filename)
    print("\nNo old model. New model has been saved.")

# Oracle 연결 닫기
oracle_connection.close()
