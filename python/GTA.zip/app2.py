from flask import Flask, jsonify
from flask_cors import CORS
import pandas as pd
from prophet import Prophet
import joblib
from datetime import datetime

app = Flask(__name__)
CORS(app)


# 각 모델을 전역으로 로드
ac_model = joblib.load('ac_model.h5')
total_model = joblib.load('total_model.h5')
plug_model = joblib.load('plug_model.h5')
light_model = joblib.load('light_model.h5')

def predict_with_model(model, future_df, date_column, energy_column):
    forecast = model.predict(future_df)
    return forecast[[date_column, 'yhat']].rename(columns={date_column: f'{model}date', 'yhat': f'{model}energy'}).to_dict(orient='records')

def total_predict_with_model():
    # total 모델의 예측 함수
    today = datetime.now()
    future = pd.date_range(start=today, periods=4 * 7 * 24 * 60, freq='1T')
    train_df = pd.DataFrame({'ds': future, 'is_weekend': (future.dayofweek >= 5).astype(int)})
    return predict_with_model(total_model, train_df, 'ds', 'total')

def plug_predict_with_model():
    # plug 모델의 예측 함수
    today = datetime.now()
    future = pd.date_range(start=today, periods=4 * 7 * 24 * 60, freq='1T')
    train_df = pd.DataFrame({'ds': future, 'is_weekend': (future.dayofweek >= 5).astype(int)})
    return predict_with_model(plug_model, train_df, 'ds', 'plug')

def light_predict_with_model():
    # light 모델의 예측 함수
    today = datetime.now()
    future = pd.date_range(start=today, periods=4 * 7 * 24 * 60, freq='1T')
    train_df = pd.DataFrame({'ds': future, 'is_weekend': (future.dayofweek >= 5).astype(int)})
    return predict_with_model(light_model, train_df, 'ds', 'light')

@app.route('/total', methods=['POST'])
def get_total_prediction():
    prediction = total_predict_with_model()
    return jsonify(prediction=prediction)

@app.route('/plug', methods=['POST'])
def get_plug_prediction():
    prediction = plug_predict_with_model()
    return jsonify(prediction=prediction)

@app.route('/light', methods=['POST'])
def get_light_prediction():
    prediction = light_predict_with_model()
    return jsonify(prediction=prediction)

if __name__ == '__main__':
    # 서버가 실행될 때 각 모델을 미리 로드
    app.run(debug=True)
