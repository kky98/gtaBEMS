import os

import pandas as pd
from prophet import Prophet
import joblib
import cx_Oracle
from datetime import datetime
# TNS_ADMIN 환경 변수 설정
os.environ["TNS_ADMIN"] = "C:/Users/rlarb/Downloads/WINDOWS.X64_193000_db_home/network/admin"
# Oracle DB 연결 설정
oracle_connection = cx_Oracle.connect('gta', 'gta', '192.168.0.42:1521/xe')

# SQL 쿼리 작성
sql_query = "SELECT * FROM be_device where b_id='gta'"


# Oracle DB에서 데이터 가져오기
df = pd.read_sql(sql_query, con=oracle_connection)
print(df.columns)
# 오늘 날짜 설정
today =datetime.now()

# Convert column names to lowercase
df.columns = df.columns.str.lower()

# 'be_date'를 기준으로 에너지 관련 열을 가져와 'ds', 'y'로 이름 변경
df = df[['be_date', 'be_plug_energy']].rename(columns={'be_date': 'ds', 'be_plug_energy': 'y'})

# 데이터 전처리: 'ds' 열을 datetime 형식으로 변환
df['ds'] = pd.to_datetime(df['ds'])

# 5분 간격으로 데이터 집계
df = df.groupby(pd.Grouper(key='ds', freq='1T')).agg({
    'y': 'sum'
}).reset_index()
# 이상치 제거
Q1 = df['y'].quantile(0.25)
Q3 = df['y'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
df_no_outliers = df[(df['y'] >= lower_bound) & (df['y'] <= upper_bound)]

# 4개월 데이터만 선택하여 모델 학습
train_df = df_no_outliers[(df_no_outliers['ds'] >= today - pd.DateOffset(months=4)) & (df_no_outliers['ds'] < today)]

# 'is_weekend' 열 추가
train_df = train_df.copy()  # train_df를 복사
train_df['is_weekend'] = (train_df['ds'].dt.dayofweek >= 5).astype(int)

# Prophet 모델 초기화 및 파라미터 튜닝
model = Prophet(
    yearly_seasonality=False,
    daily_seasonality=True,
    changepoint_prior_scale=0.01,  # 변화점의 유연성을 높임
    holidays_prior_scale=10.0,     # 휴일 효과의 유연성을 높임
    seasonality_prior_scale=10.0  # seasonality_prior_scale 값을 높게 조정
)
# 주말에 대한 주간 트렌드 추가
model.add_seasonality(name='weekend', period=7, fourier_order=40, condition_name='is_weekend')

# 모델 훈련
model.fit(train_df)

# 모델 저장
joblib.dump(model, 'plug_model.h5')

# Oracle 연결 닫기
oracle_connection.close()
