from flask import Flask, jsonify, request
from flask_cors import CORS
import joblib
from datetime import datetime, timedelta
import pandas as pd
import cx_Oracle
import os

app = Flask(__name__)
CORS(app)

# TNS_ADMIN 환경 변수 설정
os.environ["TNS_ADMIN"] = "C:/Users/rlarb/Downloads/WINDOWS.X64_193000_db_home/network/admin"

# Oracle DB 연결 설정
oracle_connection = cx_Oracle.connect('gta', 'gta', '192.168.0.42:1521/xe')
cursor = oracle_connection.cursor()

# 각 모델을 전역으로 로드
ac = joblib.load('ac_model.h5')
total = joblib.load('total_model.h5')
plug = joblib.load('plug_model.h5')
light = joblib.load('light_model.h5')
model_arr = {'ac': ac, 'total': total, 'plug': plug, 'light': light}

def predict_with_model(model, future_df):
    forecast = model.predict(future_df)
    return forecast[['ds', 'yhat']].rename(columns={'ds': 'model_date', 'yhat': 'model_energy'}).to_dict(orient='records')

def clear_previous_predictions():
    # 이전 예측 결과를 데이터베이스에서 삭제
    cursor.execute("DELETE FROM model_prediction")
    oracle_connection.commit()

@app.route('/prediction', methods=['GET'])
def predict_and_store():
    if request.method == 'GET':
        # 이전 예측 결과를 삭제
        clear_previous_predictions()

        # 예측에 필요한 데이터 프레임 생성
        today = datetime.now()
        future = pd.date_range(start=today, periods=4 * 7 * 24 * 60, freq='1T')
        train_df = pd.DataFrame({'ds': future, 'is_weekend': (future.dayofweek >= 5).astype(int)})

        # 예측 결과를 저장할 빈 리스트 생성
        predictions = []

        for model_name, model in model_arr.items():
            # 선택한 모델을 사용하여 예측 수행
            prediction = predict_with_model(model, train_df)
            predictions.extend(prediction)  # 예측 결과를 리스트에 추가

            # 예측 결과를 데이터베이스에 저장
            for entry in prediction:
                query = "INSERT INTO model_prediction (model_date, model_energy, division) VALUES (:1, :2, :3)"
                cursor.execute(query, (entry['model_date'], entry['model_energy'], model_name))
                oracle_connection.commit()
                print("커밋" + model_name)
        # 예측 데이터 저장이 완료되면 로그를 남깁니다.
        log_path = "C:/Users/rlarb/PycharmProjects/pythonProject/GTA/log/server_log.txt"
        current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"Prediction data stored at {current_datetime}"
        with open(log_path, "a") as log_file:
            log_file.write(log_message + "\n")
        return jsonify({'message': '예측이 성공적으로 저장되었습니다'})
    else:
        return jsonify({'message': '메서드가 올바르지 않습니다.'})

if __name__ == '__main__':
    app.run(debug=True)
