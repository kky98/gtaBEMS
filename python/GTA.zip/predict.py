import pandas as pd
import numpy as np
from prophet import Prophet
import joblib
import matplotlib.pyplot as plt
import json
from datetime import datetime
plt.rc('font', family='Malgun Gothic')

# ac_creat 모듈 역할을 하는 부분
today =datetime.now()
future = pd.date_range(start=today, periods=4*7*24*60, freq='1T')
train_df = pd.DataFrame({'ds': future, 'is_weekend': (future.dayofweek >= 5).astype(int)})

# 불러온 모델 사용을 위한 함수
def predict_with_model(model, future_df):
    forecast = model.predict(future_df)
    return forecast

# 불러온 모델 사용
loaded_model = joblib.load('plug_model.h5')

# 예측
prediction = predict_with_model(loaded_model, train_df)

# 결과값 프린트
print(prediction[['ds', 'yhat']])

# 결과값을 배열에 담기
result_array = prediction[['ds', 'yhat']].values

# 결과 시각화 등 필요한 후속 작업 수행

# 예측값 (일주일 예측 데이터) 시각화
prediction.plot(x='ds', y='yhat', label='Forecast')
plt.title('플러그 에너지 소비 예측 (4개월 학습 후 1주일 예측)')
plt.legend()
plt.show()

# Convert the prediction DataFrame to JSON
prediction_json = prediction[['ds', 'yhat']].to_json(orient='records')

# Convert the result array to a list of dictionaries and then to JSON
result_list = [{'ds': str(date), 'yhat': value} for date, value in result_array]
result_json = json.dumps(result_list)

# Load JSON data into variables
prediction_json_variable = json.loads(prediction_json)
result_json_variable = json.loads(result_json)

# Print or use the JSON data as needed
print("\n예측값 JSON:")
print(json.dumps(prediction_json_variable, ensure_ascii=False, indent=2))
