import joblib
from flask import Flask, jsonify
from flask_cors import CORS
from ac_predict_model import ac_predict_with_model
from total_predict_model import to_predict_with_model
from plug_predict_model import pl_predict_with_model
from light_predict_model import li_predict_with_model

app = Flask(__name__)
CORS(app)
ac_loaded_model = joblib.load('ac_model.h5')
@app.route('/ac', methods=['POST'])
def get_ac_prediction():
    prediction = ac_predict_with_model()
    print(prediction)
    return jsonify(prediction=prediction)

@app.route('/total', methods=['POST'])
def get_total_prediction():
    prediction = to_predict_with_model()
    print(prediction)
    return jsonify(prediction=prediction)

@app.route('/plug', methods=['POST'])
def get_plug_prediction():
    prediction = pl_predict_with_model()
    return jsonify(prediction=prediction)

@app.route('/light', methods=['POST'])
def get_light_prediction():
    prediction = li_predict_with_model()
    return jsonify(prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
