import pandas as pd
import numpy as np
from prophet import Prophet
import joblib
from datetime import datetime

def li_predict_with_model():
    today = datetime.now()
    future = pd.date_range(start=today, periods=4 * 7 * 24 * 60, freq='1T')
    train_df = pd.DataFrame({'ds': future, 'is_weekend': (future.dayofweek >= 5).astype(int)})

    def predict_with_model(model, future_df):
        forecast = model.predict(future_df)
        return forecast[['ds', 'yhat']].rename(columns={'ds': 'light_date', 'yhat': 'light_energy'}).to_dict(orient='records')

    loaded_model = joblib.load('light_model.h5')
    prediction = predict_with_model(loaded_model, train_df)

    return prediction

# 실행 테스트
if __name__ == "__main__":
    result = li_predict_with_model()
    print("예측값:", result)
