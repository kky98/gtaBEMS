from flask import Flask, jsonify
from flask_cors import CORS
import pandas as pd
from prophet import Prophet
import joblib
from datetime import datetime

app = Flask(__name__)

# Log the date and time when the server is executed
log_path = "C:/Users/rlarb/PycharmProjects/pythonProject/GTA/log/server_log.txt"
current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
log_message = f"Server started at {current_datetime}"
with open(log_path, "a") as log_file:
    log_file.write(log_message + "\n")

if __name__ == '__main__':
    # Load each model when the server starts
    print("Server started at:", current_datetime)
    app.run(debug=True)
