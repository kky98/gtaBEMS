// 해당 인터페이스는 MyBatis의 Mapper로 사용하기 위해 @Mapper 어노테이션이 추가되어 있습니다.
package com.spring.gta.detail.dao;

// 필요한 import 문들을 추가합니다.
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import com.spring.gta.detail.vo.DetailChartVO;

// 해당 인터페이스는 MyBatis의 Mapper 역할을 하는 인터페이스입니다.
@Mapper
public interface IDetailDAO {
	
	// 클라이언트로부터 전달받은 DetailChartVO 객체를 사용하여 차트 데이터를 가져오는 메서드를 정의합니다.
	public List<DetailChartVO> getChartData(DetailChartVO vo);
}
