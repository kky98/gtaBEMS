/**
 * 
 */
package com.spring.gta.eepad.dao;

import org.apache.ibatis.annotations.Mapper;

import com.spring.gta.eepad.vo.EepadVO;

/**
 * Class Name  : EepadDAO
 * Author      : ksj
 * Created Date: 2023. 12. 6.
 * Version: 1.0
 * Purpose:   
 * Description: 
 */
@Mapper
public interface EepadDAO {

    // eepad 조회 메소드
    public EepadVO getEepadList2(EepadVO vo);
    public EepadVO getUseEepadList2(EepadVO vo);
    }



