// 해당 클래스는 Spring의 Service 역할을 하는 클래스입니다.
package com.spring.gta.detail.service;

// 필요한 import 문들을 추가합니다.
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.gta.detail.dao.IDetailDAO;
import com.spring.gta.detail.vo.DetailChartVO;

// 해당 클래스를 Spring의 Service로 등록합니다.
@Service
public class DetailService {
	
	// IDetailDAO 타입의 빈(Bean)을 자동으로 주입받기 위해 @Autowired 어노테이션을 사용합니다.
	@Autowired
	IDetailDAO dao;
	
	// 클라이언트로부터 전달받은 DetailChartVO 객체를 사용하여 차트 데이터를 가져오는 메서드입니다.
	public List<DetailChartVO> getChartData(DetailChartVO vo) {
		// DAO 인터페이스의 getChartData 메서드를 호출하여 실제 데이터를 가져옵니다.
        return dao.getChartData(vo);
    }
}
