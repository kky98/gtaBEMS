// 차트 데이터를 담는 Value Object (VO) 클래스입니다.
package com.spring.gta.detail.vo;

// DetailChartVO 클래스 선언
public class DetailChartVO {

    // 층 정보
    private String beFloor;
    
    // 라벨 정보
    private String label;
    
    // 에어컨 에너지 소비
    private float beAcEnergy;
    
    // 플러그 에너지 소비
    private float bePlugEnergy;
    
    // 조명 에너지 소비
    private float beLightEnergy;
    
    // 현재 데이터셋 정보
    private String currentDataset;

    // 기본 생성자
    public DetailChartVO() {
        
    }

    // Getter 및 Setter 메서드들

    public String getCurrentDataset() {
        return currentDataset;
    }

    public void setCurrentDataset(String currentDataset) {
        this.currentDataset = currentDataset;
    }

    public String getBeFloor() {
        return beFloor;
    }

    public void setBeFloor(String beFloor) {
        this.beFloor = beFloor;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public float getBeAcEnergy() {
        return beAcEnergy;
    }

    public void setBeAcEnergy(float beAcEnergy) {
        this.beAcEnergy = beAcEnergy;
    }

    public float getBePlugEnergy() {
        return bePlugEnergy;
    }

    public void setBePlugEnergy(float bePlugEnergy) {
        this.bePlugEnergy = bePlugEnergy;
    }

    public float getBeLightEnergy() {
        return beLightEnergy;
    }

    public void setBeLightEnergy(float beLightEnergy) {
        this.beLightEnergy = beLightEnergy;
    }

    // toString 메서드를 재정의하여 객체의 문자열 표현을 반환합니다.
    @Override
    public String toString() {
        return "DetailChartVO [beFloor=" + beFloor + ", label=" + label + ", beAcEnergy=" + beAcEnergy
                + ", bePlugEnergy=" + bePlugEnergy + ", beLightEnergy=" + beLightEnergy + ", currentDataset="
                + currentDataset + "]";
    }
}
