// 해당 클래스는 Spring MVC에서 Controller 역할을 하는 클래스입니다.
package com.spring.gta.detail.controller;

// 필요한 import 문들을 추가합니다.
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.gta.detail.service.DetailService;
import com.spring.gta.detail.vo.DetailChartVO;

// 해당 클래스를 Spring의 Controller로 등록합니다.
@Controller
public class DetailController {
	
	// DetailService 타입의 빈(Bean)을 자동으로 주입받기 위해 @Autowired 어노테이션을 사용합니다.
	@Autowired
	DetailService service;

	// "/detail" 경로에 대한 요청을 처리하는 메서드입니다.
	@RequestMapping("/detail")
	public String dashBoardList(Model model, HttpSession session) {
		// 세션에 "login" 속성이 없으면 로그인 페이지로 리다이렉트합니다.
		if (session.getAttribute("login") == null) {
			return "redirect:/";
		}
		// "detail/detail" 뷰로 이동합니다.
		return "detail/detail";
	}

	// "/detail/chart.do" 경로에 대한 POST 요청을 처리하고, 응답 데이터를 JSON 형식으로 반환하는 메서드입니다.
	@PostMapping("/detail/chart.do")
	@ResponseBody
	public List<DetailChartVO> getChartData(@RequestBody DetailChartVO detailChartVO) {
		// DetailService의 getChartData 메서드를 호출하여 차트 데이터를 가져옵니다.
		return service.getChartData(detailChartVO);
	}
}
