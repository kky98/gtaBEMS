/**
 * 
 */
package com.spring.gta.eepad.vo;

/**
 * Class Name  : EepadVO
 * Author      : ksj
 * Created Date: 2023. 12. 6.
 * Version: 1.0
 * Purpose:   
 * Description: 
 */
public class EepadVO {
	private float averageEnergy;//a
	private Integer averageMoney;//b
	private float averageCo2;//
	private String bId;
	private float energy;
	private Integer money;
	private float co2;
	private int avgtree;
	private int currentMoney;
	private int currentEnergy;
	private int currentCo2;
	private int tree;
	public float getAverageEnergy() {
		return averageEnergy;
	}
	public void setAverageEnergy(float averageEnergy) {
		this.averageEnergy = averageEnergy;
	}
	public Integer getAverageMoney() {
		return averageMoney;
	}
	public void setAverageMoney(Integer averageMoney) {
		this.averageMoney = averageMoney;
	}
	public float getAverageCo2() {
		return averageCo2;
	}
	public void setAverageCo2(float averageCo2) {
		this.averageCo2 = averageCo2;
	}
	public String getbId() {
		return bId;
	}
	public void setbId(String bId) {
		this.bId = bId;
	}
	public float getEnergy() {
		return energy;
	}
	public void setEnergy(float energy) {
		this.energy = energy;
	}
	public Integer getMoney() {
		return money;
	}
	public void setMoney(Integer money) {
		this.money = money;
	}
	public float getCo2() {
		return co2;
	}
	public void setCo2(float co2) {
		this.co2 = co2;
	}
	public int getAvgtree() {
		return avgtree;
	}
	public void setAvgtree(int avgtree) {
		this.avgtree = avgtree;
	}
	public int getCurrentMoney() {
		return currentMoney;
	}
	public void setCurrentMoney(int currentMoney) {
		this.currentMoney = currentMoney;
	}
	public int getCurrentEnergy() {
		return currentEnergy;
	}
	public void setCurrentEnergy(int currentEnergy) {
		this.currentEnergy = currentEnergy;
	}
	public int getCurrentCo2() {
		return currentCo2;
	}
	public void setCurrentCo2(int currentCo2) {
		this.currentCo2 = currentCo2;
	}
	public int getTree() {
		return tree;
	}
	public void setTree(int tree) {
		this.tree = tree;
	}
	@Override
	public String toString() {
		return "EepadVO [averageEnergy=" + averageEnergy + ", averageMoney=" + averageMoney + ", averageCo2="
				+ averageCo2 + ", bId=" + bId + ", energy=" + energy + ", money=" + money + ", co2=" + co2
				+ ", avgtree=" + avgtree + ", currentMoney=" + currentMoney + ", currentEnergy=" + currentEnergy
				+ ", currentCo2=" + currentCo2 + ", tree=" + tree + "]";
	}
	public EepadVO() {
		
	}
	
	
	
	
}	
	

